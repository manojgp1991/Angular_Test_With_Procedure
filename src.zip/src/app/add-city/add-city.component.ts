import { Component, OnInit } from '@angular/core';
import { CityService } from '../services/city.service';
import { Router, ActivatedRoute } from '@angular/router';
import { City } from 'src/models/city';

@Component({
  selector: 'app-add-city',
  templateUrl: './add-city.component.html',
  styleUrls: ['./add-city.component.css']
})
export class AddCityComponent implements OnInit {
  tempCityId: number;

  constructor(public _cityService: CityService,
    private _router: Router,
    public _actRoute: ActivatedRoute) {
      this._actRoute.paramMap.subscribe(params => {
        this.tempCityId =  Number(params.get('id'));
      });
     }

  ngOnInit() {
    if(this.tempCityId>0) {
      this._cityService.getCityData(this.tempCityId)
      .subscribe((response: City) => {
        this._cityService.cityData =  response;
      },error => console.log(error))
    }

  }

  SaveCity() {
    debugger
    this._cityService.updateCity()
    .subscribe( res => {
      if(res>0) {
        if (this._cityService.cityData.cityId <=0) {
          alert('Record saved successfully.');
        }  else {
          alert('Record updated successfully.');
        }
        this._cityService.setDefaultCity();
        this._router.navigate(['city-list']);
      }
    }, error =>  console.log(error))

  }
}
