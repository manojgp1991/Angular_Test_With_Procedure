import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { City } from 'src/models/city';
import { map } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})

export class CityService {
    cityData: City;
    cityList: City[];
    myAppUrl = '';
    constructor(public http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
        this.setDefaultCity();
        this.cityList = [];
        this.myAppUrl = baseUrl + '/api';
    }
    setDefaultCity() {
        this.cityData = {
            cityId: 0,
            cityName: '',
            OpType: 0
        }
    }

    getCityList() {
        this.http.get(this.myAppUrl + '/Employee/GetCityList').toPromise().then(res =>
            this.cityList = res as City[]);
    }

    // updateCity() {
    //     return this.http.post(this.myAppUrl + '/Employee/CreateCity', this.cityData)
    //         .pipe(map(
    //             Response => {
    //                 return Response;
    //             }));
    // }

    updateCity() {
        return this.http.post(this.myAppUrl + '/Employee/UpdateCity', this.cityData)
            .pipe(map(
                Response => {
                    return Response;
                }));
    }

    getCityData(id: number) {
        return this.http.get(this.myAppUrl + '/Employee/DetailsCity/' + id)
            .pipe(map(
                Response => {
                    return Response;
                }));
    }
}