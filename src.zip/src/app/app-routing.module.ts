import {Routes} from '@angular/router'

import { HomeComponent } from './home/home.component';
import { CounterComponent } from './counter/counter.component';
import { FetchDataComponent } from './fetch-data/fetch-data.component';
import { FetchEmployeeComponent } from './fetch-employee/fetch-employee.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { AddCityComponent } from './add-city/add-city.component';
import { ListCityComponent } from './list-city/list-city.component';

export const  AppRoutes: Routes = [
  { path: '', component: HomeComponent, pathMatch: 'full' },
  { path: 'counter', component: CounterComponent },
  { path: 'fetch-data', component: FetchDataComponent },
  { path: 'fetch-employee', component: FetchEmployeeComponent },
  { path: 'register-employee', component: AddEmployeeComponent },
  { path: 'employee/edit/:id', component: AddEmployeeComponent },
  { path: 'edit-city/:id', component: AddCityComponent },
  { path: 'add-city', component: AddCityComponent },
  { path: 'city-list', component: ListCityComponent },
]