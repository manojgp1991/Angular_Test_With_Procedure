import { Component, OnInit } from '@angular/core';
import { CityService } from '../services/city.service';
import { City } from 'src/models/city';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-city',
  templateUrl: './list-city.component.html',
  styleUrls: ['./list-city.component.css']
})
export class ListCityComponent implements OnInit {
  localCityList: City[];

  constructor(public _cityService: CityService,
    private _router: Router) { }

  ngOnInit() {
    this.localCityList = [];
    this._cityService.getCityList();
    setTimeout(() => {
      this.localCityList = this._cityService.cityList ;
    }, 500);
  }

  // populateCity(city: City) {
  //   this._cityService.cityData = Object.assign({}, city);
  //   this._router.navigate(['edit-list']);
  // }

  delete(id: number, index) {
    if(confirm('Are you sure want to remove this city?')) {
      this._cityService.setDefaultCity();
      this._cityService.cityData.cityId = id;
      this._cityService.cityData.OpType = -1;
      this._cityService.updateCity()
      .subscribe(res => {
        if(res ===1) {
          this._cityService.cityList.splice(index,1)
          console.log(res);
          this._cityService.setDefaultCity();
        }
      });
    }
  }

}
