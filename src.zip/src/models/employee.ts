export class Employee {
    employeeId: number;
    name: string;
    city: string;
    department: string;
    gender: string;
}
